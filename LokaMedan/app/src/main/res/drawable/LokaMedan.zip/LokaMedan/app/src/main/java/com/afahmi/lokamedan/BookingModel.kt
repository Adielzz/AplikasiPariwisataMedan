package com.afahmi.lokamedan

data class BookingModel(
    val nama: String,
    val lokasi: String
)
