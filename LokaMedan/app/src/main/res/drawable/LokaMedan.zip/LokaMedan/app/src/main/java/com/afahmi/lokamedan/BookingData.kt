package com.afahmi.lokamedan

data class BookingData(
    val nama: String,
    val lokasi: String
)
