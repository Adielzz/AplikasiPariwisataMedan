package com.afahmi.lokamedan

data class WisataModel(
    val nama: String,
    val lokasi: String,
    val deskripsi: String,
    val gambar: Int
)
